/*
 * TitleImage.java
 *
 * Created on 2005/10/23, 10:42
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package presentationbox;
import java.io.FileNotFoundException;
import java.io.IOException;
import javax.vecmath.Vector3f;
import org.jdesktop.lg3d.sg.Appearance;
import org.jdesktop.lg3d.sg.Shape3D;

import org.jdesktop.lg3d.wg.Component3D;
import org.jdesktop.lg3d.wg.Container3D;
import org.jdesktop.lg3d.wg.Frame3D;
import org.jdesktop.lg3d.wg.Thumbnail;
import org.jdesktop.lg3d.utils.shape.ImagePanel;
import org.jdesktop.lg3d.sg.Texture;
import org.jdesktop.lg3d.utils.c3danimation.NaturalMotionAnimation;

import org.jdesktop.lg3d.wg.Cursor3D;
import org.jdesktop.lg3d.sg.Texture;
import org.jdesktop.lg3d.sg.utils.image.TextureLoader;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;


/**
 *
 * @author yasuhiro
 */
public class TitleImage {
    
    private Frame3D frame;
    private float IMAGE_WIDTH = 0.15f;
    private float IMAGE_HEIGHT = 0.07f;

    /** Creates a new instance of TitleImage */
    public TitleImage() {
        try{
            frame = new Frame3D();
            Component3D c = new Component3D();
            ImagePanel i = new ImagePanel("title.png",IMAGE_WIDTH,IMAGE_HEIGHT);
            c.addChild(i);
            frame.addChild(c);
            frame.setPreferredSize(new Vector3f(IMAGE_WIDTH, IMAGE_HEIGHT,0.01f));
            frame.setEnabled(true);
            frame.setVisible(true);
            c.setAnimation(new NaturalMotionAnimation(1000) );
            c.setRotationAxis(0.0f, 1.0f,0.0f);
            c.changeRotationAngle((float)Math.PI*4.0f, 40000);
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    
    public void close(){
        frame.changeEnabled(false);
    }
}
