/*
 * StateChangeEvent.java
 *
 * Created on 2005/10/11, 19:20
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package presentationbox;

import org.jdesktop.lg3d.wg.event.LgEvent;
import org.jdesktop.lg3d.wg.event.LgEventSource;

/**
 *
 * @author yasuhiro
 */
public class StateChangeEvent extends LgEvent {

    private LgEventSource source;
    private Class sourceClass;
    private boolean state;

    /** Creates a new instance of StateChangeEvent */
    public StateChangeEvent(LgEventSource source, boolean state) {
        this.source = source;
        this.sourceClass = source.getClass();

        this.state = state;
    }

    public LgEventSource getSource() {
        return source;
    }

    public Class getSourceClass() {
        return sourceClass;
    }

    public boolean getState() {
        return state;
    }

    
}
