/*
 * PresentationBox.java
 *
 * Created on 2005/10/10, 23:12
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package presentationbox;

import java.io.FileNotFoundException;
import java.io.IOException;
import javax.vecmath.Vector3f;
import javax.vecmath.Color3f;
import org.jdesktop.lg3d.sg.Appearance;
import org.jdesktop.lg3d.sg.Shape3D;
import org.jdesktop.lg3d.utils.shape.Text2D;

import org.jdesktop.lg3d.utils.action.RotateActionBoolean;
import org.jdesktop.lg3d.utils.action.RotateActionFloat;
import org.jdesktop.lg3d.utils.actionadapter.ToggleAdapter;
import org.jdesktop.lg3d.utils.c3danimation.NaturalMotionAnimation;
import org.jdesktop.lg3d.utils.eventadapter.MousePressedEventAdapter;

import org.jdesktop.lg3d.utils.eventadapter.MouseClickedEventAdapter;
import org.jdesktop.lg3d.wg.event.MouseEvent3D.ButtonId;

import org.jdesktop.lg3d.utils.shape.Box;
import org.jdesktop.lg3d.utils.shape.SimpleAppearance;
import org.jdesktop.lg3d.utils.shape.FuzzyEdgePanel;
import org.jdesktop.lg3d.utils.shape.GlassyPanel;
import org.jdesktop.lg3d.wg.Component3D;
import org.jdesktop.lg3d.wg.Container3D;
import org.jdesktop.lg3d.wg.Frame3D;
import org.jdesktop.lg3d.wg.Thumbnail;
import org.jdesktop.lg3d.utils.shape.ImagePanel;
import org.jdesktop.lg3d.sg.Texture;
import org.jdesktop.lg3d.sg.Appearance;
import org.jdesktop.lg3d.utils.eventadapter.EventAdapter;
import org.jdesktop.lg3d.utils.action.ActionBoolean;
import org.jdesktop.lg3d.wg.event.LgEventSource;
import org.jdesktop.lg3d.utils.action.ActionNoArg;

import org.jdesktop.lg3d.wg.Cursor3D;
import org.jdesktop.lg3d.sg.Texture;
import org.jdesktop.lg3d.sg.utils.image.TextureLoader;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import java.util.Enumeration;
import java.util.Vector;
import java.util.ArrayList;

/**
 *
 * @author yasuhiro
 */
public class PresentationBox {
    
    private ArrayList<Texture> ja;
    private ArrayList<Texture> en;
    private boolean jaMode = true;
    private int backPageNumber = 2;
    private int backNo = 2;
    private int currentPageNumber = 1;
    private float BOX_SIZE = 0.08f;
    private float IMAGE_WIDTH = 0.15f;
    private float IMAGE_HEIGHT = 0.13f;
    
    private TexturePanelBox mainbox;
    private TexturePanelBox thumbbox;
    private Text2D pageNo;
    
    private Frame3D frame;
    
    /** Creates a new instance of PresentationBox */
    protected PresentationBox(){}
    
    public PresentationBox(ArrayList<Texture> ja, ArrayList<Texture> en) {
        
        this.ja = ja;
        this.en = en;
                
        // フレームの生成
        frame = new Frame3D();

        // Boxを作成
        mainbox = this.makeTexturePanelBox();

        // 滑らかに動かすためのお約束
        mainbox.setAnimation(new NaturalMotionAnimation(1000));
        // 左クリックで回転
        MouseClickedEventAdapter leftClickedAdapter =
                new MouseClickedEventAdapter(ButtonId.BUTTON1,
                new PresentationBox.PageAction(this, (float)(Math.PI / 2.0), 1000));
        // 右クリックで逆回転
        MouseClickedEventAdapter rightClickedAdapter =
                new MouseClickedEventAdapter(ButtonId.BUTTON3,
                new PresentationBox.PageAction(this, - (float)(Math.PI / 2.0), 1000));

        // コンポーネントにイベントアダプタを登録
        mainbox.addListener(leftClickedAdapter);
        mainbox.addListener(rightClickedAdapter);
        
        // 親にイベントを伝播する
        mainbox.setMouseEventPropagatable(true);
        
        // コンポーネントをコンテナに追加
        // ここではコンテナを使用していないので、
        // 直接フレームに追加
        frame.addChild(mainbox);

        // サムネイル
        thumbbox = this.makeTexturePanelBox();
        thumbbox.setAnimation(new NaturalMotionAnimation(1000));
        Thumbnail thumbnail = new Thumbnail();

        // サムネイル上で真中クリックをすると最小化
        MouseClickedEventAdapter thumbnailMiddleClickedAdapter =
                new MouseClickedEventAdapter(ButtonId.BUTTON2,
                new ActionNoArg(){
                    public void performAction(LgEventSource source) {
                        if( frame.isVisible() ){
                            frame.changeVisible(false);
                        } else {
                            frame.changeVisible(true);
                        }
                    }
                });

        thumbnail.addListener(thumbnailMiddleClickedAdapter);
        
        thumbnail.addChild(thumbbox);
        frame.setThumbnail(thumbnail);
        
                
        // ToggleButtonの作成
        try {
            ToggleButton tButton = new ToggleButton();
            EventAdapter eventAdapter = new StateChangeEventAdapter(
                    new ActionBoolean(){
                         public void performAction(LgEventSource source, boolean state){
                            switchMode();
                        }
                    });
             tButton.setTranslation(0.1f, -0.06f, 0.082f);
             tButton.addListener(eventAdapter);
             frame.addChild(tButton);
        } catch (Exception e){
            e.printStackTrace();
        }

        Component3D button = makeButton();
        if(button != null)
            frame.addChild(button);
        else System.out.println("button is null");

        pageNo = new Text2D("1", new Color3f(0.5f,0.7f,1.0f), "Serif", 32, 0 );
        Component3D pageComponent = new Component3D();
        pageComponent.setScale(0.15f);
        pageComponent.setTranslation(-0.10f,-0.08f,0.08f);
        pageComponent.addChild(pageNo);        
        frame.addChild(pageComponent);

        // フレームの表示
        // フレームの大きさを設定
        frame.setPreferredSize(new Vector3f(BOX_SIZE, BOX_SIZE, BOX_SIZE));

        // フレームの表示
        frame.changeEnabled(true);
        frame.changeVisible(true);

    }
    
    public PresentationBox(ArrayList ja) {
        this(ja, null);
    }

    // イベント処理の対象となるオブジェクトの取得
    protected TexturePanelBox[] getActionItems(){
        TexturePanelBox[] value = { mainbox,thumbbox };
        return value;
    }
    
    private class TexturePanelBox extends Component3D {
        private Vector<Appearance> front = new Vector();
        private Vector<Appearance> back = new Vector();
        private Vector<Component3D> componentList = new Vector();
        public Vector<Appearance> getFront(){
            return front;
        }
        public Vector<Appearance> getBack(){
            return back;
        }
        public Vector<Component3D> getComponents(){
            return componentList;
        }
    }

    private class PageAction implements ActionNoArg {
        PresentationBox pBox;
        float diff;
        int duration;

        /** Creates a new instance of PageAction */
        public PageAction(PresentationBox pBox, float diff, int duration) {
            this.pBox = pBox;
            this.diff = diff;
            this.duration = duration;
        }
    
        // イベント処理をおこなうためのメソッド
        public void performAction(LgEventSource source) {
        
            // ページ変更処理
            if (diff > 0)
                pBox.next(diff,duration);
            else
                pBox.prev(diff,duration);
        }
    }
    
    private TexturePanelBox makeTexturePanelBox() {
        ImagePanel frontPanel;
        ImagePanel backPanel;
        
        TexturePanelBox primary = new TexturePanelBox();
        Vector<Appearance> front = primary.getFront();
        Vector<Appearance> back = primary.getBack();
        Vector<Component3D> componentList = primary.getComponents();

        // ベースとなるボックス
        Box box = new Box(BOX_SIZE, BOX_SIZE, BOX_SIZE,
                          new SimpleAppearance(1.0f,1.0f,0.8f,1.0f));
        primary.addChild(box);
                
        for(int i=0; i < 4; i++){
            // パネルの作成
            frontPanel = new ImagePanel(IMAGE_WIDTH, IMAGE_HEIGHT);
            Component3D sub = new Component3D();
            
            // フロントパネルの作成
            SimpleAppearance appearance = new SimpleAppearance(1.0f,1.0f,1.0f);
            appearance.setCapability(Appearance.ALLOW_TEXTURE_WRITE);
            if(i==3)
                appearance.setTexture(ja.get(ja.size()-1));
            else
                appearance.setTexture(ja.get(i));
            frontPanel.setAppearance(appearance);
            front.add(appearance);
            Component3D frontComponent = new Component3D();
            frontComponent.addChild(frontPanel);
            frontComponent.setRotationAxis(0.0f, 1.0f, 0.0f);
            
            // バックパネルの作成
            backPanel = new ImagePanel(IMAGE_WIDTH, IMAGE_HEIGHT);
            appearance = new SimpleAppearance(1.0f,1.0f,1.0f);
            appearance.setCapability(Appearance.ALLOW_TEXTURE_WRITE);
            if(i==3) 
                appearance.setTexture(en.get(en.size()-1));
            else
                appearance.setTexture(en.get(i));
            backPanel.setAppearance(appearance);
            back.add(appearance);
            Component3D backComponent = new Component3D();
            backComponent.addChild(backPanel);
            backComponent.setRotationAxis(0.0f, 1.0f, 0.0f);
            backComponent.setRotationAngle( 2 * (float) Math.PI/2.0f );
            
            sub.addChild(frontComponent);
            sub.addChild(backComponent);
            // 滑らかに動かすためのお約束
            sub.setAnimation(new NaturalMotionAnimation(1000));
            sub.setRotationAxis(0.0f, 1.0f, 0.0f);
            sub.setRotationAngle( - i * (float) Math.PI/2.0f );
            //sub.setTranslation(0.0f, 0.0f, 0.1f);
            sub.setTranslation(-1 * ( BOX_SIZE + 0.0005f ) * (float)Math.sin(Math.PI / 2.0 * i), 0.0f,
                    ( BOX_SIZE + 0.0005f ) * (float)Math.cos(Math.PI / 2.0 * i) );
            componentList.add(sub);            
            primary.addChild(sub);
        }
        return primary;
    }
   
    private Component3D makeButton(){
        Component3D result = null;

        try{
            // Window Close Button
            BufferedImage closeImage = ImageIO.read(ClassLoader.getSystemResourceAsStream("resources/images/button/window-close.png"));
            Texture closeTexture = new TextureLoader(closeImage).getTexture();
            ImagePanel closePanel = new ImagePanel(0.01f,0.01f);
            SimpleAppearance closeAppearance = new SimpleAppearance(1.0f,1.0f,0.8f,1.0f, SimpleAppearance.ENABLE_TEXTURE);
            closeAppearance.setTexture(closeTexture);
            closePanel.setAppearance(closeAppearance);

            Component3D closeComponent = new Component3D();
            closeComponent.addChild(closePanel);
            closeComponent.setTranslation(0.01f, 0.0f, 0.0f);
            closeComponent.addListener(
                new MouseClickedEventAdapter(
                    new ActionNoArg() {
                        public void performAction(LgEventSource source) {
                            frame.changeEnabled(false);
                        }
                }));
            result = new Component3D();
            result.addChild(closeComponent);
            
            // Window Minimize Button
            BufferedImage minimizeImage = ImageIO.read( ClassLoader.getSystemResourceAsStream("resources/images/button/window-minimize.png"));
            Texture minimizeTexture = new TextureLoader(minimizeImage).getTexture();
            ImagePanel minimizePanel = new ImagePanel(0.01f,0.01f);
            SimpleAppearance minimizeAppearance = new SimpleAppearance(1.0f,1.0f,0.8f,1.0f, SimpleAppearance.ENABLE_TEXTURE);
            minimizeAppearance.setTexture(minimizeTexture);
            minimizePanel.setAppearance(minimizeAppearance);
            Component3D minimizeComponent = new Component3D();
            minimizeComponent.addChild(minimizePanel);
            minimizeComponent.addListener(
                new MouseClickedEventAdapter(
                    new ActionNoArg() {
                        public void performAction(LgEventSource source) {
                            // ちょっとしたお遊び
                            TexturePanelBox[] items = getActionItems();
                            float frameRotation = frame.getFinalRotationAngle();
                            try{
                                synchronized(frame){
                                    frame.changeRotationAngle(frame.getFinalRotationAngle()+(float)Math.PI*4.0f,1000);
                                    for(TexturePanelBox item : items){
                                        for(Component3D child : item.getComponents() ){
                                            Vector3f loc = new Vector3f();
                                            child.getFinalTranslation(loc);
                                            child.changeTranslation(loc.x,loc.y-0.25f,loc.z,2000);
                                            child.changeRotationAngle(child.getFinalRotationAngle() + (float)Math.PI*2.0f,1000);
                                        }
                                    }
                                    frame.wait(1000);
                                    for(TexturePanelBox item : items)
                                        for(Component3D child : item.getComponents() )
                                            child.setVisible(false);
                                    frame.setRotationAngle( frameRotation );
                                    frame.changeVisible(false);
                                    frame.wait(1000);
                                }
                            } catch(Exception e){
                                e.printStackTrace();
                            }
                            for(TexturePanelBox item : items){
                                for(Component3D child : item.getComponents() ){
                                    Vector3f loc = new Vector3f();
                                    child.getFinalTranslation(loc);
                                    child.changeTranslation(loc.x,loc.y+0.25f,loc.z,1000);
                                    child.setVisible(true);
                                }
                            }
                        }
                }));

            result.addChild(minimizeComponent);            
            result.setTranslation(0.085f, 0.08f, 0.082f);
            result.setCursor(Cursor3D.SMALL_CURSOR);

        } catch (Exception e){
            e.printStackTrace();
            result = null;
        }

        return result;
    }

    
    public synchronized void sleep(long msec){
        //指定ミリ秒実行を止めるメソッド
    	try
        {
            wait(msec);
        }catch(InterruptedException e){}
    }

    public void changePage(int diff){
        currentPageNumber += diff;
        if(currentPageNumber > ja.size())
            currentPageNumber -= ja.size();
        else if(currentPageNumber < 1)
            currentPageNumber += ja.size();
        String no = String.valueOf(currentPageNumber);
        pageNo.setString(no);
    }
    
    // ページ番号の加算および書き換え
    // 書き換え対象はボックスの後ろ側
    public void next(float diff, int duration) {        
        backNo++;
        if(backNo == 4) backNo=0;
        backPageNumber ++;
        if( backPageNumber == ja.size() ) backPageNumber -= ja.size();

        TexturePanelBox[] items = this.getActionItems();
        for(TexturePanelBox item : items){
            item.changeRotationAngle(item.getFinalRotationAngle()+diff,duration);

            Vector<Appearance> front = item.getFront();
            Vector<Appearance> back = item.getBack();
            Appearance a;
            a = front.get((backNo)%4);
                a.setTexture(ja.get(backPageNumber));
            a = back.get((backNo)%4);
                a.setTexture(en.get(backPageNumber));
        }
        changePage(1);
    }

    // ページ番号の書き換え
    // 書き換え対象はボックスの右側
    public void prev(float diff, int duration) {
        
        // 右側の番号、ページ番号の生成
        int rightNo = backNo;
        int rightPageNumber = backPageNumber + 3;
        if(rightPageNumber >= ja.size()) rightPageNumber -= ja.size();
        
        TexturePanelBox[] items = this.getActionItems();
        for(TexturePanelBox item : items){
            item.changeRotationAngle(item.getFinalRotationAngle()+diff,duration);

            Vector<Appearance> front = item.getFront();
            Vector<Appearance> back = item.getBack();
            System.out.println("bn="+rightNo+" rpn="+rightPageNumber);
            Appearance a;
            a = front.get((rightNo)%4);
                a.setTexture(ja.get(rightPageNumber));
            a = back.get((rightNo)%4);
                a.setTexture(en.get(rightPageNumber));
        }

        // ページ番号の修正
        backNo--;
        if( backNo == -1 ) backNo=3;
        backPageNumber --;
        if( backPageNumber == -1 ) backPageNumber += ja.size();
        
        changePage(-1);
    }
    
    public void switchMode() {
        TexturePanelBox[] items = this.getActionItems();

        for(TexturePanelBox item : items){
            for(Component3D child : item.getComponents() ){
                child.changeRotationAngle(child.getFinalRotationAngle() + (float)Math.PI,1000);
            }
        }
    }
}

