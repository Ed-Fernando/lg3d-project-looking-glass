/*
 * StateChangeEventAdapter.java
 *
 * Created on 2005/10/11, 20:01
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package presentationbox;

import org.jdesktop.lg3d.utils.action.ActionBoolean;
import org.jdesktop.lg3d.utils.eventadapter.EventAdapter;
import org.jdesktop.lg3d.wg.event.LgEvent;

/**
 *
 * @author yasuhiro
 */
public class StateChangeEventAdapter implements EventAdapter {
    private static final Class[] targetEventClasses = {
        StateChangeEvent.class
    };

    private ActionBoolean action;

    public StateChangeEventAdapter(ActionBoolean action) {
        // StateChangeEventAdapter で扱うアクションは
        // ActionBoolean のみ
        this.action = action;
    }

    public Class[] getTargetEventClasses() {
        return targetEventClasses;
    }

    public void processEvent(LgEvent event) {
        // イベントが StateChangeEvent であれば、
        // アクションをコールする
        if (event instanceof StateChangeEvent) {
            boolean state = ((StateChangeEvent)event).getState();
            action.performAction(event.getSource(), state);
        }
    }
}
