/*
 * ToggleButton.java
 *
 * Created on 2005/10/11, 19:14
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package presentationbox;

import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.imageio.ImageIO;
import javax.vecmath.Vector3f;
import org.jdesktop.lg3d.sg.Texture;
import org.jdesktop.lg3d.sg.utils.image.TextureLoader;
import org.jdesktop.lg3d.sg.Appearance;
import org.jdesktop.lg3d.sg.Shape3D;
import org.jdesktop.lg3d.utils.action.ActionNoArg;
import org.jdesktop.lg3d.utils.eventadapter.MouseClickedEventAdapter;
import org.jdesktop.lg3d.utils.shape.ImagePanel;
import org.jdesktop.lg3d.utils.shape.SimpleAppearance;
import org.jdesktop.lg3d.wg.Component3D;
import org.jdesktop.lg3d.wg.Cursor3D;
import org.jdesktop.lg3d.wg.event.LgEventListener;
import org.jdesktop.lg3d.wg.event.LgEventSource;
import org.jdesktop.lg3d.utils.c3danimation.NaturalMotionAnimation;


/**
 *
 * @author yasuhiro
 */
public class ToggleButton extends Component3D {
    
    private static float SIZE = 0.03f;
    private static String JA_IMAGE = "ja.png";
    private static String EN_IMAGE = "en.png";

    private Texture jaTexture;
    private Texture enTexture;

    private ToggleButton toggleButton;
    
    private boolean state;
    
    /** Creates a new instance of ToggleButton */
    public ToggleButton() throws FileNotFoundException, IOException {
        
        toggleButton=this;
        toggleButton.setAnimation(new NaturalMotionAnimation(1000));
        toggleButton.setRotationAxis(1.0f,0.0f,0.0f);
        
        ClassLoader classloader = this.getClass().getClassLoader();

        InputStream imageStream
            = classloader.getResourceAsStream(JA_IMAGE);
        if (imageStream == null) {
            imageStream = new FileInputStream(JA_IMAGE);
        }
        BufferedImage jaImage = ImageIO.read(imageStream);
        jaTexture = new TextureLoader(jaImage).getTexture();

        // 日本語
        SimpleAppearance jaAppearance = new SimpleAppearance(0.0f, 0.0f, 0.0f,
                                          SimpleAppearance.DISABLE_CULLING);
        jaAppearance.setCapability(Appearance.ALLOW_TEXTURE_WRITE);
        jaAppearance.setTexture(jaTexture);

        ImagePanel jaPanel = new ImagePanel(SIZE, SIZE);
        jaPanel.setAppearance(jaAppearance);
        Component3D jaComponent = new Component3D();
        jaComponent.addChild(jaPanel);
        jaComponent.setRotationAxis(1.0f,0.0f,0.0f);
        jaComponent.setTranslation(0.0f,0.0f, -0.0001f);
        jaComponent.setRotationAngle((float)Math.PI);
        addChild(jaComponent);

        // English
        imageStream = classloader.getResourceAsStream(EN_IMAGE);
        if (imageStream == null) {
            imageStream = new FileInputStream(EN_IMAGE);
        }
        BufferedImage enImage = ImageIO.read(imageStream);
        enTexture = new TextureLoader(enImage).getTexture();

        SimpleAppearance enAppearance = new SimpleAppearance(0.0f, 0.0f, 0.0f,
                                          SimpleAppearance.DISABLE_CULLING);
        enAppearance.setCapability(Appearance.ALLOW_TEXTURE_WRITE);
        enAppearance.setTexture(enTexture);

        ImagePanel enPanel = new ImagePanel(SIZE, SIZE);
        enPanel.setAppearance(enAppearance);
        Component3D enComponent = new Component3D();
        enComponent.addChild(enPanel);
        addChild(enComponent);


        setCursor(Cursor3D.SMALL_CURSOR);

        addListener(
            new MouseClickedEventAdapter(
                new ActionNoArg() {
                    public void performAction(LgEventSource source) {
                        state = !state;
                        if (state) {
                            toggleButton.changeRotationAngle(toggleButton.getFinalRotationAngle()+(float)Math.PI*5);
                        } else {
                            toggleButton.changeRotationAngle((toggleButton.getFinalRotationAngle()+(float)Math.PI*5));
                        }

                        fireStateChangeEvent();
                    }
                }));

        setMouseEventPropagatable(true);
    }

    // 1. ボタンが押されたときの処理
    private void fireStateChangeEvent() {
        // StateChangeEvent を生成し、ポストする
        StateChangeEvent event = new StateChangeEvent(this, state);
        postEvent(event);
    }

}
