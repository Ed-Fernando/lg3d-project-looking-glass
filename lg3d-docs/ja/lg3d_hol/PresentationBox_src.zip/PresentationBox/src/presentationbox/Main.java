/*
 * Main.java
 *
 * Created on 2005/10/10, 23:11
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package presentationbox;

import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.jdesktop.lg3d.sg.Texture;
import org.jdesktop.lg3d.sg.utils.image.TextureLoader;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
        
/**
 *
 * @author yasuhiro
 */
public class Main {
    
    private String listEn ="list_en.txt";
    private String listJa ="list_ja.txt";
    private PresentationBox pBox;
    
    /** Creates a new instance of Main */
    public Main() {
        ArrayList<Texture> ja = new ArrayList<Texture>();;
        ArrayList<Texture> en = new ArrayList<Texture>();;
        BufferedReader reader, reader2;
        TextureLoader loader;
        BufferedImage image;
        Texture texture;

        // ファイルリストを読み込む
        // 適当に実装
        // 日本語版、英語版の両方が存在していることが必須
        // 日本語版が基準となっており、英語版は日本語版と同数必要
        try{
            // タイトル
            TitleImage t = new TitleImage();
            
            // ファイルリストの読み込み
            reader = new BufferedReader( new InputStreamReader(ClassLoader.getSystemResourceAsStream(listJa)) );
            reader2 = new BufferedReader( new InputStreamReader(ClassLoader.getSystemResourceAsStream(listEn)) );
            int num = 0;
            String line;
            // ファイルリストから画像ファイルを読み込みテクスチャの作成をする
            while ( (line = reader.readLine()) != null ){
                image = ImageIO.read( ClassLoader.getSystemResourceAsStream(line) );
                texture = new TextureLoader(image).getTexture();
                ja.add(num, texture);
                image = ImageIO.read( ClassLoader.getSystemResourceAsStream(reader2.readLine()) );
                texture = new TextureLoader(image).getTexture();
                en.add(num, texture);
                num ++;
            }
            
            t.close();
            
        } catch (Exception e){
            e.printStackTrace();
            System.exit(-1);
        }
        
        try{
            // PresentationBoxの作成、表示
            pBox = new PresentationBox(ja, en);

        } catch (Exception e){
            e.printStackTrace();
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new Main();
    }
    
}
